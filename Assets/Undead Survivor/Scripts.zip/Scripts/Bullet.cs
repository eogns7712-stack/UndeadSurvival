using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bullet : MonoBehaviour
{
    // 데미지와 관통변수 선언
    public float damage;
    public int per;
    public int prefabId; // [추가] 파편 생성을 위한 프리팹 ID 저장 변수

    Rigidbody2D rigid;  // Rigidbody2D 변수 생성 및 초기화

    // [추가] 최적화를 위한 최대 사거리 제한 변수들
    Vector3 startPosition;
    public float maxRange = 12f; // 총알이 화면 밖까지 불필요하게 날아가는 것을 방지하기 위한 최대 사거리 설정

    // [추가] 폭발형 무기(폭탄) 관련 변수들
    public bool isBomb = false;
    public float explosionRadius = 4.5f;
    public int bombStage = 0; // 0: 일반, 1: M1 파편, 2: M2 불바다
    public GameObject fireZonePrefab; // 인스펙터에서 설정

    // [추가] 파편 탄환에 초월 비주얼을 입히기 위한 참조 보관용
    [HideInInspector] public Sprite shardSprite;

    void Awake()
    {   // 변수 초기화
        rigid = GetComponent<Rigidbody2D>();
    }

    // [버그 수정 완료] Init 시점에 isBomb 상태가 초기화되어 사라지지 않도록 선택적 매개변수 구조로 통합 변경합니다.
    public void Init(float damage, int per, Vector3 dir, Vector3 startPos = default, int bombStage = 0, int prefabId = 0, bool isBomb = false)
    {
        this.damage = damage;
        this.per = per;
        this.prefabId = prefabId;
        this.bombStage = bombStage;
        this.isBomb = isBomb; // 전달받은 폭탄 플래그를 안전하게 유지합니다.
        
        // 폭탄 무기(id == 4)의 경우 던지는 사거리(distance)가 maxRange로 이미 치환되어 들어오므로, 
        // 일반 투사체일 때만 무기 최대 기본 사거리인 12f를 강제 보정합니다.
        this.maxRange = isBomb ? maxRange : 12f;
        this.startPosition = startPos == default ? transform.position : startPos;

        // [삽 잔상 해결] 풀에서 가져온 객체의 렌더러와 상태를 즉시 초기화
        SpriteRenderer sr = GetComponent<SpriteRenderer>();
        if (sr != null) sr.enabled = true;

        if (per >= 0)   // 관통(per)이 -1(무한)보다 큰 것에 대해서는 속도적용
        {
            rigid.velocity = dir * 15f;
        }
    }

    // [복구 완료] 탄환 및 수류탄이 일정 사거리를 날아가면 풀러로 되돌아가는 최적화 스케줄러 복구
    void Update()
    {
        if (!GameManager.instance.isLive)
            return;

        // 근접 공전 무기(삽, per == -100)의 경우는 최대 사거리 회수 검사에서 안전하게 제외합니다.
        if (per == -100)
            return;

        // 발사된 시작 지점으로부터 현재 이동한 물리적 거리를 연산합니다.
        float travelDistance = Vector3.Distance(startPosition, transform.position);
        
        if (travelDistance >= maxRange)
        {
            if (isBomb)
            {
                // 수류탄 등 폭발 무기는 지정된 최대 사거리에 안전하게 착탄하면 제자리에서 즉시 기폭 연산을 작동시킵니다.
                Explode();
            }
            else
            {
                // 일반 탄환은 물리 속도를 0으로 밀고 화면상에서 안전하게 풀러로 비활성화 반입합니다.
                rigid.velocity = Vector2.zero;
                gameObject.SetActive(false);
            }
        }
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if (!collision.CompareTag("Enemy") || per == -100) return;

        if (isBomb)
        {
            Explode();
            return;
        }

        per--;

        if (per < 0)
        {
            rigid.velocity = Vector2.zero;
            gameObject.SetActive(false);
        }
    }

    void Explode()
    {
        // 1. 폭발 반경 내부의 모든 Enemy 레이어 스캔
        Collider2D[] hitEnemies = Physics2D.OverlapCircleAll(transform.position, explosionRadius, LayerMask.GetMask("Enemy"));
        
        foreach (Collider2D enemyCollider in hitEnemies)
        {
            Enemy enemy = enemyCollider.GetComponent<Enemy>();
            if (enemy != null)
            {
                enemy.TakeDamage(damage);
            }
        }

        // [이펙트 비주얼 연동 완료] 유니티 에디터 이펙트 없이 코드로만 주황빛 불꽃 파동 원을 실시간으로 그려서 터트립니다.
        GameObject fxObject = new GameObject("TemporaryExplosionVFX");
        fxObject.transform.position = transform.position;
        TemporaryExplosionFX fxComp = fxObject.AddComponent<TemporaryExplosionFX>();
        
        // 폭발 반경을 전달하여 그 크기에 맞는 실시간 그라데이션 원을 생성합니다.
        fxComp.PlayExplosion(explosionRadius);

        // [M1 파편 수류탄 진화]: 1단계 초월 시 파편 분산
        if (bombStage >= 1)
        {
            for (int i = 0; i < 8; i++)
            {
                Transform fragment = GameManager.instance.pool.Get(prefabId).transform;
                fragment.position = transform.position;
                Vector3 dir = Quaternion.Euler(0, 0, i * 45) * Vector3.up;
                
                Bullet shardBullet = fragment.GetComponent<Bullet>();
                shardBullet.Init(damage * 0.5f, 0, dir, transform.position, 0, prefabId, false);
                
                // [파편 스프라이트 적용] 무기 고유 초월 스프라이트가 존재하면 파편 투사체 이미지로 치환합니다.
                if (shardSprite != null)
                {
                    SpriteRenderer sr = fragment.GetComponent<SpriteRenderer>();
                    if (sr != null) sr.sprite = shardSprite;
                }
            }
        }

        // [M2 소이 탄두 최종 진화]: 2단계 초월 시 불바다 생성
        if (bombStage >= 2)
        {
            if (fireZonePrefab != null)
            {
                GameObject fireZone = Instantiate(fireZonePrefab, transform.position, Quaternion.identity);
                Destroy(fireZone, 3f);
            }
            else
            {
                // [VFX 직접 생성] 소이 탄두용 프리팹이 없을 시, 천천히 박동하고 지속 피해를 주도록 코드로 직접 렌더링 생성
                GameObject fireZone = new GameObject("TemporaryFireZone");
                fireZone.transform.position = transform.position;
                TemporaryFireZone zoneComp = fireZone.AddComponent<TemporaryFireZone>();
                zoneComp.SetupZone(damage * 0.25f, explosionRadius * 0.85f, 3f);
            }
        }

        // 2. 효과음 재생
        AudioManager.instance.PlaySfx(AudioManager.Sfx.Dead); // 폭발 사운드 대용 활용

        // 3. 탄환 객체 리셋 및 풀 반입
        rigid.velocity = Vector2.zero;
        isBomb = false;
        gameObject.SetActive(false);
    }
}

// [추가] 외부 이펙트 프리팹을 전혀 쓰지 않고 오직 C# 연산으로만 불꽃 팽창을 표현하는 경량 이펙트 컴포넌트
public class TemporaryExplosionFX : MonoBehaviour
{
    private SpriteRenderer sr;
    private float maxDuration = 0.22f; // 폭발이 커지고 사라지는 시간
    private float elapsed = 0f;
    private Vector3 maxScale;

    public void PlayExplosion(float radius)
    {
        sr = gameObject.AddComponent<SpriteRenderer>();
        
        // 유니티 외부 리소스 없이 메모리에서 오렌지색 원형 스프라이트를 실시간 생성하여 부착
        sr.sprite = CreateCircleSprite();
        
        // 적이나 맵보다 상위에 강제 렌더링되도록 Sorting Order 세팅
        sr.sortingOrder = 10; 
        
        transform.localScale = Vector3.one * 0.1f;
        // 폭발 반경에 비례하여 부풀어 오를 최종 스케일 지정
        maxScale = Vector3.one * radius * 1.8f; 
    }

    // [VFX 프리팹 미사용] 코드 단에서 실시간 오렌지-레드 화염 그라데이션 원을 직접 그리는 함수
    Sprite CreateCircleSprite()
    {
        int size = 128; // 더 부드러운 원형 출력을 위해 텍스처 해상도를 128로 증폭합니다.
        Texture2D texture = new Texture2D(size, size, TextureFormat.RGBA32, false);
        float center = size / 2f;
        float radius = size / 2f - 4f;

        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                float dist = Vector2.Distance(new Vector2(x, y), new Vector2(center, center));
                if (dist <= radius)
                {
                    // 중심에서 가장자리로 갈수록 부드럽게 감쇠되는 보간
                    float alpha = Mathf.Clamp01((radius - dist) / 4.0f);
                    // 흰색 기본 베이스에 알파값만 지정해주어야 SpriteRenderer.color의 화염 컬러가 완벽하게 발색됩니다.
                    texture.SetPixel(x, y, new Color(1f, 1f, 1f, alpha));
                }
                else
                {
                    texture.SetPixel(x, y, Color.clear);
                }
            }
        }
        texture.Apply();
        return Sprite.Create(texture, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 100f);
    }

    void Update()
    {
        elapsed += Time.deltaTime;
        float t = elapsed / maxDuration;

        // 1. 크기가 급격하게 부풀어 올랐다가 멈춤
        transform.localScale = Vector3.Lerp(Vector3.one * 0.1f, maxScale, Mathf.Sin(t * Mathf.PI * 0.5f));

        // 2. 색상이 붉은색으로 변하면서 서서히 투명해짐
        if (sr != null)
        {
            float alpha = Mathf.Lerp(0.85f, 0f, t);
            sr.color = new Color(1f, Mathf.Lerp(0.45f, 0.15f, t), 0.05f, alpha);
        }

        // 3. 연출 시간이 끝나면 오브젝트 자동 파괴 및 메모리 정리
        if (elapsed >= maxDuration)
        {
            Destroy(gameObject);
        }
    }
}

// [M2용 추가] 프리팹 없이도 작동하는 황금-주황빛 박동 소이 화염 지대 스크립트
public class TemporaryFireZone : MonoBehaviour
{
    private SpriteRenderer sr;
    private float damage;
    private float radius;
    private float duration;
    private float timer = 0f;
    private float tickTimer = 0f;
    private float tickRate = 0.5f; // 0.5초당 한 번씩 주변 적에게 피해전달

    public void SetupZone(float damage, float radius, float duration)
    {
        this.damage = damage;
        this.radius = radius;
        this.duration = duration;

        sr = gameObject.AddComponent<SpriteRenderer>();
        sr.sprite = CreateFireZoneSprite();
        sr.sortingOrder = 4; // 바닥 장판 느낌으로 적들 살짝 하단 렌더링

        transform.localScale = Vector3.one * radius * 2f;
    }

    Sprite CreateFireZoneSprite()
    {
        int size = 128;
        Texture2D texture = new Texture2D(size, size, TextureFormat.RGBA32, false);
        float center = size / 2f;
        float r = size / 2f - 4f;

        for (int y = 0; y < size; y++)
        {
            for (int x = 0; x < size; x++)
            {
                float dist = Vector2.Distance(new Vector2(x, y), new Vector2(center, center));
                if (dist <= r)
                {
                    // 불완전한 경계선 및 반투명한 바닥 화염 장판 그라데이션
                    float alpha = Mathf.Clamp01((r - dist) / 12.0f) * 0.5f;
                    texture.SetPixel(x, y, new Color(1f, 1f, 1f, alpha));
                }
                else
                {
                    texture.SetPixel(x, y, Color.clear);
                }
            }
        }
        texture.Apply();
        return Sprite.Create(texture, new Rect(0, 0, size, size), new Vector2(0.5f, 0.5f), 100f);
    }

    void Update()
    {
        timer += Time.deltaTime;
        if (timer >= duration)
        {
            Destroy(gameObject);
            return;
        }

        // 황금-오렌지-레드 빛으로 호흡하듯 천천히 박동하는 비주얼 기믹
        float beat = Mathf.PingPong(timer * 5f, 1f);
        float scaleMultiplier = 1f + (beat * 0.1f);
        transform.localScale = Vector3.one * radius * 2f * scaleMultiplier;

        if (sr != null)
        {
            // 황금-주황-적색의 일렁이는 컬러 보간 처리
            sr.color = Color.Lerp(new Color(1f, 0.82f, 0f, 0.45f), new Color(1f, 0.35f, 0f, 0.3f), beat);
        }

        // 소이 탄두 지속 도트 데미지 틱 스케줄러
        tickTimer += Time.deltaTime;
        if (tickTimer >= tickRate)
        {
            tickTimer = 0f;
            Collider2D[] targets = Physics2D.OverlapCircleAll(transform.position, radius, LayerMask.GetMask("Enemy"));
            foreach (Collider2D target in targets)
            {
                Enemy enemy = target.GetComponent<Enemy>();
                if (enemy != null)
                {
                    enemy.TakeDamage(damage);
                }
            }
        }
    }
}