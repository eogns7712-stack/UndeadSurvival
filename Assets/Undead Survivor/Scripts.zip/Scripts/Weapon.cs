using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Weapon : MonoBehaviour
{
    // 무기ID, 프리팹ID, 데미지, 개수 변수 선언
    public int id;
    public int prefabId;
    public float damage;
    public int count;

    // [버그 수정 완료] 무기 고유 레벨업 공속(value)과 장갑 공속 변환 비율이 정밀하게 누적 곱 연산되도록 baseSpeed를 추가 정의합니다.
    private float baseSpeed = 1.8f;

    // [버그 수정 완료] 외부 기어(Glove) 스크립트가 default 분기로 연사속도를 멋대로 덮어씌우는 현상을 원천 방어하기 위해
    // speed 변수를 스마트 프로퍼티로 선언하여 무기 고유의 공속 기획 밸런스를 철저히 수호합니다.
    private float _speed;
    // id를 사용하여 연사속도 계산을 완전히 분리합니다.
    public float speed
    {
        get { return _speed; }
        set
        {
            if (originData != null && originData.itemType == ItemData.ItemType.Bomb)
            {
                // 수류탄 고유 연산: Glove 보너스만 적용
                _speed = baseSpeed * Character.WeaponRate;
            }
            else
            {
                _speed = value;
            }
        }
    }

    float timer;
    Player player;  // Player의 자식 오브젝트를 편히 불러오기 위한 player변수 선언
    public int masterUpgradeCount = 0; // [추가] 무기 한계돌파(최대 레벨 이후 추가 강화) 횟수 기록

    // [초월 진화용 추가] 무기 진화 단계 스프라이트 및 데이터
    public SpriteRenderer mySpriteRenderer;
    public ItemData originData;

    // masterUpgradeCount의 단순 누적이 아닌, 데이터 배열 길이에 기인한 정밀 초월 단계(Stage) 연산기 설계
    public int CurrentStage
    {
        get
        {
            if (originData == null || originData.damages.Length == 0) return 1;
            if (masterUpgradeCount <= 0) return 0;
            // 예: 배열 크기가 5일 때, 1~5회 강화는 1단계(M1), 6~10회 강화는 2단계(M2)로 정확히 분간합니다.
            return 1 + (masterUpgradeCount - 1) / originData.damages.Length;
        }
    }

    void Awake()
    {
        player = GameManager.instance.player;   // 게임매니저에 들어있는 player를 이용해 변수 초기화
    }

    void Update()
    {
        if (!GameManager.instance.isLive)
            return;
        switch (id)  // 무기ID에 따라 로직을 분리할 switch생성
        {
            case 0 :    // 무기ID 하나씩 case ~ break로 감싸기
                transform.Rotate(Vector3.back * speed * Time.deltaTime);   // Vector3.back = (0,0,-1)

                break;

            case 4 :    // [추가] 무기ID 4 : 폭탄 던지기 무기 (신규 무기)
                timer += Time.deltaTime;
                if (timer > speed)
                {
                    timer = 0f;
                    FireBomb();
                }
                break;

            default :   // 그외 나머지 경우가 있다면 default ~ break으로 감싸기
                timer += Time.deltaTime;    // Update에서 deltaTime 계속 더하기 (timer = 게임시간)

                if (timer > speed)
                {
                    timer = 0f;
                    Fire();
                }
                break;
        }
    }

    // [수정] 무기 초월 및 이미지 스프라이트 단계적 진화 시스템 탑재
    public void MasterUpgrade(float damageMultiplier, int extraCount)
    {
        masterUpgradeCount++;
        
        // [밸런스 기획 변경] 총(id == 1) 무기는 일방적인 데미지 가산을 거부하고 1차(M1), 2차(M2) 맞춤 성능으로 재편합니다.
        if (id == 1)
        {
            // 총은 별도 맞춤 함수를 통해 밸런스를 적용하므로 무조건 누적 가산 연산을 분기 격리합니다.
            UpdateGunTranscendenceBalance();
        }
        else if (id == 4)
        {
            // 수류탄의 초월 시에는 무기 대미지 가산만 진행하고, 공속이 총알처럼 빨라지는 현상을 완벽 차단합니다.
            damage += damage * damageMultiplier;
            count += extraCount;
            // 수류탄 고유의 묵직한 투척 속도 제약 유지
            ApplyGear(); 
        }
        else
        {
            damage += damage * damageMultiplier; // 일반 무기는 기존 규칙대로 데미지 증가율 누적
            count += extraCount;                 // 발사 수 증가
            speed *= 0.95f;                      // 쿨타임 5% 단축
        }

        // [진화 이미지 교체] 1차 초월(M1)시 갈퀴/라이플, 2차 초월(M2)시 낫/샷건 등으로 진화
        UpdateEvolutionVisual();

        // 회전형 무기인 경우 즉시 재배치 필요
        if (id == 0)
        {
            Batch();
        }
    }

    // [추가] 총(itemId == 1)의 마스터 단계별(M1 라이플, M2 샷건) 전용 밸런스 튜닝
    void UpdateGunTranscendenceBalance()
    {
        int stage = CurrentStage;
        if (stage == 1) // 1단계 초월: 라이플 진화
        {
            // 공격력은 줄어들고 연사속도는 비약적으로 가증
            damage = originData.baseDamage * 0.7f * Character.Damage; // 공격력 30% 감산
            speed = 0.22f * Character.WeaponRate;                    // 연사 쿨타임 대폭 감소 (고속 연사)
            count = originData.baseCount + Character.Count;          // 기본 발사수 유지
        }
        else if (stage >= 2) // 2단계 초월: 샷건 최종 단계
        {
            // 공격력이 대폭 상승하고 연사속도 감소 + 격발 시 3발 분산 구현을 위한 쿨타임 증가
            damage = originData.baseDamage * 2.2f * Character.Damage; // 데미지 120% 폭등
            speed = 1.35f * Character.WeaponRate;                    // 연사 속도 대폭 감소 (묵직한 사격)
            count = 3;                                               // 발사 수 강제 3발 (산탄 구현용)
        }
    }

    // [추가] 초월 레벨에 근거하여 무기와 탄환의 외형 스프라이트를 변경해 주는 함수
    void UpdateEvolutionVisual()
    {
        if (originData == null) return;

        // 초월 차수에 매칭되는 진화 스프라이트가 존재하는지 판별
        // index 0: M1 진화형, index 1: M2 진화형 등 (ItemData의 customEvolutions 배열 참고)
        int evolutionIndex = masterUpgradeCount - 1;

        if (originData.customEvolutions != null && evolutionIndex < originData.customEvolutions.Length)
        {
            Sprite nextSprite = originData.customEvolutions[evolutionIndex];
            if (nextSprite != null)
            {
                // 1. 플레이어가 장착하고 조준하는 Hand 스프라이트 이미지 진화
                Hand hand = player.hands[(int)originData.itemType];
                if (hand != null && hand.spriter != null)
                {
                    hand.spriter.sprite = nextSprite;
                }

                // 2. 만약 무기 오브젝트 자체에 렌더러가 직접 달린 형태라면 이미지 변경
                if (mySpriteRenderer != null)
                {
                    mySpriteRenderer.sprite = nextSprite;
                }
            }
        }
    }

    // [추가 완료] 장갑(Glove) 등 기어 업그레이드 수신부 연동
    // BroadcastMessage 수신 시 각 무기군 고유의 연사 속도 기획 비율을 완벽 수호하도록 고정합니다.
    public void ApplyGear()
    {
        switch (id)
        {
            case 0: // 근접 공전 삽
                speed = 150 * Character.WeaponSpeed;
                Batch();
                break;
            case 4: // 수류탄 투척 연사력 지연 고정
                // [버그 수정 완료] 장갑 레벨이 오르더라도 수류탄이 총알 속도(0.5f) 등으로 덮어씌워지지 않도록 방어합니다.
                // 수류탄 고유 레벨업 등으로 지정된 baseSpeed 기본 스펙에 장갑 기어 강화 비율을 정상 보존 적용합니다.
                speed = baseSpeed * Character.WeaponRate; 
                break;
            case 1: // 원거리 총
                int stage = CurrentStage;
                if (stage == 1) // M1 라이플
                {
                    speed = 0.22f * Character.WeaponRate;
                }
                else if (stage >= 2) // M2 샷건
                {
                    speed = 1.35f * Character.WeaponRate;
                }
                else // 기본 권총
                {
                    speed = 0.5f * Character.WeaponRate;
                }
                break;
            default:
                speed = 0.5f * Character.WeaponRate;
                break;
        }
    }

    public void LevelUp(float damage, int count)
    {
        // 만렙 이전 일반 성장의 연사 속도 세팅
        this.damage = damage;
        this.count += count;

        if (id == 0)    // 속성 변경과 동시에 근접무기의 경우 배치도 필요하니 함수호출
            Batch();

        // [버그 해결 완료] 수류탄 레벨업 시 획득한 고유의 쿨다운 속도를 baseSpeed로 갱신하여, 
        // Glove 방송 수신 시 덮어씌워지지 않게 고정합니다. (수류탄 고유의 묵직함을 지키기 위해 baseSpeed 보존 설계)
        if (id == 4 && originData.speeds != null && masterUpgradeCount < originData.speeds.Length)
        {
            baseSpeed = originData.speeds[masterUpgradeCount];
        }

        player.BroadcastMessage("ApplyGear",SendMessageOptions.DontRequireReceiver);   // 나중에 추가된 무기에도 강화된 값을 적용하기 위함
    }

    public void Init(ItemData data) // Weapon 초기화 함수에 스크립트블 오브젝트를 매개변수로 받아 활용 (영상11 33:30)
    {
        // Basic Set
        name = "Weapon" + data.itemId;
        transform.parent = player.transform;
        transform.localPosition = Vector3.zero; // 지역 위치인 localPosition을 원점으로 변경

        // Property set
        id = data.itemId;
        damage = data.baseDamage * Character.Damage;    // Player의 무기 데미지를 정하는 구간
        count = data.baseCount + Character.Count;   // Player의 원거리 관통력과 근접무기 갯수를 정하는 구간
        originData = data; // 초월 진화 데이터 추적용 보관

        // [버그 해결] 수류탄 생성 즉시 고유의 레벨 1 기본 스피드를 baseSpeed에 초기화 바인딩
        if (id == 4 && data.speeds != null && data.speeds.Length > 0)
        {
            baseSpeed = data.speeds[0];
        }

        for (int index = 0; index < GameManager.instance.pool.prefabs.Length; index++)
        {
            if (data.projectile == GameManager.instance.pool.prefabs[index])    // 프리팹 아이디는 풀링매니저의 변수에서 찾아내 초기화
            {
                prefabId = index;
                break;
            }
        }

        // 수량 및 관통 초기화 완료 후 수치 반영 가동
        ApplyGear();

        // Hand set
        Hand hand = player.hands[(int)data.itemType];   // enum값 itemType 값 앞에 int타입을 작성해 강제 형변환, 근거리(Melee)=0, 원거리(Range)=1
        hand.spriter.sprite = data.hand;    // 스크립트블 오브젝트의 데이터로 스프라이트 적용
        hand.gameObject.SetActive(true);

        player.BroadcastMessage("ApplyGear",SendMessageOptions.DontRequireReceiver); // BroadcastMessage : 특정 함수 호출을 모든 자식에게 방송하는 함수, 나중에 추가된 무기에도 강화된 값을 적용하기 위함
        // BroadcastMessage의 두번째 인자값으로 SendMessageOptions.DontRequireReceiver 추가, 반드시 답변을 할 필요가 없다
    }

    void Batch()    // 근접무기 재배치용 함수
    {
        for (int index = 0; index < count; index++) // for문으로 count만큼 풀링에서 가져오기
        {
            Transform bullet;

            if (index < transform.childCount)   // childCount : 자신의 자식 오브젝트 개수 확인
            {
                bullet = transform.GetChild(index); // index가 아직 childCount 범위 내라면 GetChild함수로 가져오기
            }
            else    // 가져올 오브젝트가 없다면 오브젝트 풀링에서 가져오기 [ 최적화 ]
            {
                bullet = GameManager.instance.pool.Get(prefabId).transform;   // GameObject에서 Transform을 가져오기 때문에 Transform bullet
            }
            bullet.parent = transform;  // parent 속성을 통해 bullet의 부모를 현재 오브젝트로 설정, Weapon이 회전하면 Bullet도 회전하게 하기위함

            bullet.localPosition = Vector3.zero;    // 부모 기준 위치를 (0,0,0)으로 설정
            bullet.localRotation = Quaternion.identity;     // 부모 기준 회전값을 0도로 초기화
            Vector3 rotVec = Vector3.forward * 360 * index / count; //회전 : 순서대로 360을 나누값을 Z축에 적용
            bullet.Rotate(rotVec);
            bullet.Translate(bullet.up * 1.5f, Space.World);  // Translate()함수로 자신의 위쪽으로 이동
            // Space.World의 의미 : 월드좌표 기준으로 이동, 즉 부모 회전에 영향을 받지않아 정확한 위치에 배치

            bullet.GetComponent<Bullet>().Init(damage, -100, Vector3.zero); // -100 is Infinity Per.
            
            // [초월 투사체 분리 반영] 사출되는 투사체 전용 이미지 등록 체크
            int evolutionIndex = masterUpgradeCount - 1;
            if (originData.customProjectileEvolutions != null && evolutionIndex >= 0 && evolutionIndex < originData.customProjectileEvolutions.Length)
            {
                Sprite projectileSprite = originData.customProjectileEvolutions[evolutionIndex];
                SpriteRenderer bRenderer = bullet.GetComponent<SpriteRenderer>();
                if (bRenderer != null && projectileSprite != null)
                {
                    bRenderer.sprite = projectileSprite;
                }
            }
            else if (originData.customEvolutions != null && evolutionIndex >= 0 && evolutionIndex < originData.customEvolutions.Length)
            {
                // 발사체 전용이 없을 시, 무기 스프라이트(Melee)로 대체
                Sprite projectileSprite = originData.customEvolutions[evolutionIndex];
                SpriteRenderer bRenderer = bullet.GetComponent<SpriteRenderer>();
                if (bRenderer != null && projectileSprite != null)
                {
                    bRenderer.sprite = projectileSprite;
                }
            }
        }
    }

    void Fire() // 총알 사출 구현함수
    {
        if (!player.scanner.nearestTarget)  // 지정한 목표가 없으면 넘어가는 조건의 로직
            return;
            
        // 총알이 나가는 방향 계산
        Vector3 targetPos = player.scanner.nearestTarget.position;  // 타겟(Enemy)의 위치는 Player의 하위오브젝트 scanner가 nearestTarget변수로 들고있음
        Vector3 dir = targetPos - transform.position;   // 크기가 포함된 방향 : 목표위치 - 나의위치
        dir = dir.normalized;   // normalized : 현재 벡터의 방향은 유지하고 크기를 1로 변환한 속성(정규화)

        // masterUpgradeCount 누적수가 아닌, 정밀 검사식 CurrentStage가 2단계 이상일 때에만 샷건 사격을 발사합니다.
        if (id == 1 && CurrentStage >= 2)
        {
            // 중심 조준 방향(dir)을 기준으로 좌우 15도씩 틀어 총 3발 발사
            float[] shotgunAngles = { -15f, 0f, 15f };
            for (int i = 0; i < 3; i++)
            {
                // 각도만큼 방향 벡터 회전 연산
                Vector3 rotDir = Quaternion.AngleAxis(shotgunAngles[i], Vector3.forward) * dir;

                Transform bullet = GameManager.instance.pool.Get(prefabId).transform;
                bullet.position = transform.position;
                bullet.rotation = Quaternion.FromToRotation(Vector3.up, rotDir);

                Bullet bulletComponent = bullet.GetComponent<Bullet>();
                bulletComponent.Init(damage, 1, rotDir, transform.position); // 관통력 1 보정

                // 탄환 이미지 진화형 샷건 스프라이트로 치환 적용
                int evolutionIndex = masterUpgradeCount - 1;
                if (originData.customProjectileEvolutions != null && evolutionIndex >= 0 && evolutionIndex < originData.customProjectileEvolutions.Length)
                {
                    Sprite projectileSprite = originData.customProjectileEvolutions[evolutionIndex];
                    SpriteRenderer bRenderer = bullet.GetComponent<SpriteRenderer>();
                    if (bRenderer != null && projectileSprite != null)
                    {
                        bRenderer.sprite = projectileSprite;
                    }
                }
            }
        }
        else
        {
            // 기본 총 혹은 1단계 초월 (M1 라이플: 초고속 점사) 격발 로직 (M1 Lv.2, M1 Lv.3 상태에서도 정밀 1발 점사 보장!)
            Transform bullet = GameManager.instance.pool.Get(prefabId).transform;
            bullet.position = transform.position;   // 기존 근접무기 생성 로직을 그대로 활용하면서 위치는 Player위치로 지정
            bullet.rotation = Quaternion.FromToRotation(Vector3.up, dir); // Quaternion.FromToRotation(시작방향, 목표방향) : 지정된 축을 중심으로 목표를 향해 회전하는 함수
            
            // Bullet.cs 에 플레이어 위치를 전달하여 최대 사거리 제한을 연산하도록 초기화
            bullet.GetComponent<Bullet>().Init(damage, count, dir, transform.position); 

            // [초월 비주얼 반영] 사출되는 원거리 총알 이미지도 진화형으로 교체
            int evolutionIndex = masterUpgradeCount - 1;
            if (originData.customProjectileEvolutions != null && evolutionIndex >= 0 && evolutionIndex < originData.customProjectileEvolutions.Length)
            {
                Sprite projectileSprite = originData.customProjectileEvolutions[evolutionIndex];
                SpriteRenderer bRenderer = bullet.GetComponent<SpriteRenderer>();
                if (bRenderer != null && projectileSprite != null)
                {
                    bRenderer.sprite = projectileSprite;
                }
            }
        }

        AudioManager.instance.PlaySfx(AudioManager.Sfx.Range); // 원거리 무기 사출시 효과음 재생
    }

    void FireBomb() // [추가] 폭탄 무기 발사 메커니즘
    {
        Vector3 targetPos;
        // 타겟이 있으면 타겟 방향, 없으면 플레이어가 바라보는 앞 방향으로 투척
        if (player.scanner.nearestTarget)
        {
            targetPos = player.scanner.nearestTarget.position;
        }
        else
        {
            targetPos = transform.position + (player.inputVec != Vector2.zero ? (Vector3)player.inputVec.normalized * 3f : Vector3.up * 3f);
        }

        Vector3 dir = targetPos - transform.position;
        
        // [사거리 수정 완료] 수류탄의 사거리가 너무 긴 버그를 잡기 위해, 최대 투척 제한 거리를 기존 5f에서 3.2f로 낮췄습니다.
        float maxBombRange = 3.2f; // ★ 이 값을 줄이면 사거리가 더욱 짧아집니다.
        float distance = Mathf.Min(dir.magnitude, maxBombRange); 
        dir = dir.normalized;

        Transform bomb = GameManager.instance.pool.Get(prefabId).transform;
        bomb.position = transform.position;

        // Bullet.cs 의 Init 시점에 폭발물 플래그가 동작하도록 설정
        Bullet bombBullet = bomb.GetComponent<Bullet>();
        if (bombBullet != null)
        {
            // [초월 단계 계산] 1단계(3회이상) / 2단계(6회이상)
            int currentStage = 0;
            if (masterUpgradeCount >= 6) currentStage = 2; // M2
            else if (masterUpgradeCount >= 3) currentStage = 1; // M1

            // [비행 속도 조절 연동] 수류탄 투척 비행 속도를 조절하는 인자입니다.
            // 사거리가 짧아진 만큼 자연스러운 비행 낙하 곡선을 위해 속도를 살짝 보정(9f -> 7.5f)해 주는 것이 좋습니다.
            float throwSpeed = 7.5f; // ★ 비행 속도를 줄여서 수류탄이 너무 쌩하고 멀리 가버리는 느낌을 추가로 차단했습니다.
            
            // [파편 스프라이트 연동] 1단계 초월 이상일 경우, 파편에 입힐 투사체 에셋 스프라이트를 전달합니다.
            if (currentStage >= 1 && originData != null)
            {
                int evolutionIndex = masterUpgradeCount - 1;
                if (masterUpgradeCount >= 3 && originData.customProjectileEvolutions != null)
                {
                    bombBullet.shardSprite = originData.customProjectileEvolutions[0]; 
                }
                else if (originData.customEvolutions != null && evolutionIndex >= 0 && evolutionIndex < originData.customEvolutions.Length)
                {
                    bombBullet.shardSprite = originData.customEvolutions[evolutionIndex];
                }
            }

            // [수정] Init 시그니처에 마지막 인수로 true를 직접 전달하여 isBomb 상태가 완벽하게 유지되도록 강제 주입합니다.
            bombBullet.Init(damage, 1, dir, transform.position, currentStage, prefabId, true);
            
            // Rigidbody 물리 속도에 직접 연동 대입
            bombBullet.GetComponent<Rigidbody2D>().velocity = dir * throwSpeed;
        }

        AudioManager.instance.PlaySfx(AudioManager.Sfx.Range); // 원거리 무기 사출시 효과음 재생
    }
}